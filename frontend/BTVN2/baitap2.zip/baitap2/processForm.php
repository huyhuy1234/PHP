<?php 
var_dump($_POST);
// input type file
var_dump($_FILES);
 ?>